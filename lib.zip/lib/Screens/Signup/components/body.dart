import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Login/login_screen.dart';
import 'package:flutter_auth/Screens/Signup/components/background.dart';
import 'package:flutter_auth/components/User_signup.dart';
import 'package:flutter_auth/components/pass.dart';
import 'package:flutter_auth/components/button_signup.dart';
import 'package:flutter_auth/components/phone.dart';
import 'package:flutter_auth/components/user.dart';
import 'package:flutter_svg/svg.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
             
            SizedBox(height: size.height * 0.15),
            RoundeduserField(
              onChanged: (value) {},
            ),
            SizedBox(height: size.height * 0.01),
            RoundedmailField(
              onChanged: (value) {},
            ),
            SizedBox(height: size.height * 0.01),
            RoundedpassField(
              onChanged: (value) {},
            ),
            SizedBox(height: size.height * 0.01),
            RoundedphoneField(
              onChanged: (value) {},
            ),
            SizedBox(height: size.height * 0.04),
               RoundedButtonsignup(),
            SizedBox(height: size.height * 0.01),
             Image.asset(
              "assets/images/IMG_0825.PNG",
              width: size.width*300,
             
            ),
        
          ],
        ),
      ),
    );
  }
}

