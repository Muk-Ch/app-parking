import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';

class Background extends StatelessWidget {
  final Widget child;
  const Background({
    Key key,
    @required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height,
      width: double.infinity,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Positioned(
            bottom: 50,
            child: Container(
              width: 375,
              height: 400,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  width: 5,
                  color: B),
                borderRadius: BorderRadius.all(
                  Radius.circular(40)
                ),
                  )
              ),
              ),
             SizedBox(height: size.height * 0.02),
          child,
        ],
      ),
    );
  }
}
