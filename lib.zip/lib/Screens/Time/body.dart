import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/qr_code/qr_screen.dart';
import 'package:flutter_auth/Screens/Time/background.dart';
import 'package:flutter_auth/constants.dart';



class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
             SizedBox(height: size.height * 0.02),
            Text(
              "PARKING RESERVATION",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 30,
                fontFamily: 'Asap'
              ),
            ),
            
            Text(
              "SYSTEM",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 30,
                fontFamily: 'Asap'
              ),
            ),
            
            Positioned(
              top: 0,
              child: Container(
                width: 400,
                height: 300,
                decoration: BoxDecoration(
                  image:DecorationImage(image:AssetImage('assets/images/time.PNG') ),
                ),
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(50, 12, 12, 12),
              child : Align(
                            alignment: Alignment.bottomLeft,
                            child: Text(
                                        "Date",
                                        style: TextStyle(
                                                          fontWeight: FontWeight.bold,
                                                          fontSize: 20,
                                                          fontFamily: 'Asap',
                                                          letterSpacing: 0.5
                                                        ),
                                        ),
                            )
            ),

            Container(
                      width: 300,
                      height: 50,
                      decoration: BoxDecoration(
                                                color: Colors.white,
                                                border: Border.all(
                                                                    width: 5,
                                                                    color: Colors.black),
                                                borderRadius: BorderRadius.all(
                                                                                Radius.circular(5)
                                                                              ),  
                                                ),
                        child: Center(
                                      child: Text(
                                                   '${now.day} : ${now.month} : ${now.year}',
                                                    style: TextStyle(
                                                                      fontSize: 20,
                                                                      color: A,
                                                                      fontWeight: FontWeight.bold
                                                                    ),
                      
                                                  )
                                      ),
              ),
               SizedBox(height: size.height * 0.03),
              Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(50, 12, 12, 12),
                      child : Align(
                                     alignment: Alignment.bottomLeft,
                                     child: Text(
                                                  "Time in",
                                                  style: TextStyle(
                                                                    fontWeight: FontWeight.bold,
                                                                    fontSize: 20,
                                                                    fontFamily: 'Asap',
                                                                    letterSpacing: 0.1),
                                                  ),
                                      ),
              
                    ),
          
              Positioned(
                          top: 50,
                          child: Container(
                                            width: 300,
                                            height: 50,
                                            decoration: BoxDecoration(
                                                                        color: Colors.white,
                                                                        border: Border.all(
                                                                                            width: 5,
                                                                                            color: Colors.black),
                                                                        borderRadius: BorderRadius.all(
                                                                                                        Radius.circular(5)
                                                                                                      ),  
                                                                        ),
                child: Center(
                              child: Text(
                                            '${now.hour} : ${now.minute} : ${now.second}',
                                            style: TextStyle(
                                            fontSize: 20,
                                            color: A,
                                            fontWeight: FontWeight.bold),
                                          )
                              ),
            ),
            ),
             SizedBox(height: size.height * 0.05),
              FlatButton(
              
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
              child: Text( "Confirm",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold)),
              textColor: Colors.white,
              color: Colors.black,
              
              shape: RoundedRectangleBorder(
                 side:BorderSide(color: Colors.white, width: 3),
                 borderRadius: BorderRadius.circular(10)
                 ),
                  onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return QrScreen();
                    },
                  ),
                );

                  },
            ), 
             SizedBox(height: 0.01,),

          ],
        ),

      ),
    );
  }
}


