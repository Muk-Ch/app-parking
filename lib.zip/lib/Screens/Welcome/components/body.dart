import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Login/login_screen.dart';
import 'package:flutter_auth/Screens/Signup/signup_screen.dart';
import 'package:flutter_auth/Screens/Welcome/components/background.dart';
import 'package:flutter_auth/components/rounded_button.dart';


class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Welcome!!",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 50,
                fontFamily: 'Asap'
              ),
            ),
            Image.asset(
              "assets/images/welcom.jpg",
              height: 350,
              width: 500,
            ),
             SizedBox(height: size.height * 0.02),
            Text(
              "Parking Reservation System",
                 style: TextStyle(
                   fontWeight: FontWeight.bold,
                   fontSize: 30,
                   fontFamily: 'Asap'
                  
                   ),
              
            ),
            SizedBox(height: size.height * 0.05),
            RoundedButton(
              text: "LOGIN",
              press: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return LoginScreen();
                    },
                  ),
                );
              },
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 10),
              width: size.width * 0.8,
              child: OutlineButton(
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
              child: Text( "SIGN UP",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold)),
              borderSide: BorderSide(color: Colors.black, width: 3),
              color: Colors.white,
              textColor: Colors.black,
              shape: RoundedRectangleBorder(
                 borderRadius: BorderRadius.circular(29)
                 ),
                  onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return SignUpScreen();
                    },
                  ),
                );
              },
            ),
            )
          ],
        ),
      ),
    );
  }
}


