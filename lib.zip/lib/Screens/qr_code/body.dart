import 'package:flutter/material.dart';

import 'package:flutter_auth/Screens/qr_code/background.dart';
import 'package:flutter_auth/constants.dart';



class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
              
          ],
        ),

      ),
    );
  }
}


