import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/qr_code/body.dart';



class QrScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Body(),
      
    );
    
  }
}
