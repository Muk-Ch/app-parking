import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';

class RoundeduserField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const RoundeduserField({
    Key key,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      width: 300,
      
      child: TextField(
        obscureText: true,
        onChanged: onChanged,
        cursorColor: A,
        decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: Colors.black,
              width: 2 )
          ),
          hintText: "Username",
          prefixIcon: Icon(
            Icons.person,
            color: B,
          ),
        ),
        
      ),
      
    );
  }
}
