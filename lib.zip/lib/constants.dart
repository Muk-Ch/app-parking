import 'package:flutter/material.dart';

const A = Color(0xFF556bf4);
const B = Color(0xFFdb2254);
const C = Color(0xFFE1A3B2);
const D = Color(0xFFe87191);
const E = Color(0xFFFF6787);
